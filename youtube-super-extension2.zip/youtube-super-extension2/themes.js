const THEME_STYLES = {
    black: `
        /* --- MAIN BACKGROUNDS --- */
        html, [dark], body, #background, #masthead-background { background-color: #000000 !important; }
        ytd-app, #content, ytd-watch-flexy { background: #000000 !important; }
        
        /* --- HEADER, CHIPS & SIDEBAR --- */
        #masthead-container, ytd-masthead, #masthead,
        ytd-feed-filter-chip-bar-renderer, #chips-wrapper,
        ytd-mini-guide-renderer, ytd-guide-renderer, #guide-content { 
            background-color: #000000 !important; 
        }

        /* --- PROFILE/YOU PAGE HEADER FIX --- */
        ytd-profile-header-renderer, 
        ytd-profile-header-renderer #header,
        ytd-c4-tabbed-header-renderer, #channel-header, 
        .tp-yt-app-header,
        #page-header-container, #page-header, 
        yt-page-header-renderer, yt-page-header-view-model,
        ytd-tabbed-page-header { 
            background-color: #000000 !important; 
            --yt-spec-base-background: #000000 !important;
        }
        
        /* --- PLAYLIST PANEL FIX --- */
        ytd-playlist-panel-renderer, ytd-playlist-panel-renderer #container, 
        ytd-playlist-panel-renderer #header-contents, 
        div.header.style-scope.ytd-playlist-panel-renderer, 
        .playlist-items.ytd-playlist-panel-renderer { 
            background-color: #000000 !important; 
        }

        /* --- PROFILE & MENU BUTTONS --- */
        yt-flexible-actions-view-model .yt-spec-button-shape-next--tonal,
        ytd-button-renderer.style-scope.ytd-simple-menu-header-renderer,
        .yt-spec-button-shape-next--tonal {
            background-color: #111111 !important;
            color: #ffffff !important;
            border: 1px solid #333 !important;
        }
        
        /* --- SEARCH BAR --- */
        ytd-searchbox, #search-form, #container.ytd-searchbox, 
        .ytSearchboxComponentInputBox {
            background-color: #111111 !important;
            border-color: #333 !important;
        }
        input.ytSearchboxComponentInput {
            background-color: transparent !important;
            color: #ffffff !important;
        }
        #voice-search-button, ytd-button-renderer#voice-search-button {
            background-color: #111111 !important;
        }

        /* --- BUTTONS FIX --- */
        html body ytd-app ytd-masthead #search-icon-legacy,
        #search-icon-legacy {
            background: #111111 !important;
            border: none !important;
            border-radius: 0 40px 40px 0 !important; 
            margin-left: -2px !important;
            box-shadow: none !important;
        }
        #masthead #end #buttons ytd-button-renderer,
        ytd-masthead #buttons ytd-button-renderer {
            background-color: #111111 !important;
            border: 1px solid #333 !important;
            border-radius: 40px !important;
        }
        .ytd-profile-header-renderer ytd-button-renderer,
        ytd-profile-header-renderer #buttons ytd-button-renderer {
            background-color: #111111 !important;
            border: 1px solid #333 !important;
            border-radius: 40px !important;
        }

        /* --- SEARCH HISTORY DROPDOWN --- */
        .sbdd_b, .sbsb_a, .sbsb_c, .sbdd_a,
        ytd-search-suggestions-renderer,
        .ytSearchboxComponentSuggestionsContainer {
            background-color: #111111 !important;
            border: 1px solid #333 !important;
        }
        .sbsb_c:hover, .sbsb_d { background-color: #222 !important; }
        .sbqs_c, .sbsb_d, .sbpqs_a { color: #ffffff !important; } 
        .sbsb_i { color: #ff3131 !important; }

        /* --- TOPIC CHIPS --- */
        yt-chip-cloud-chip-renderer {
            background-color: #111111 !important;
            border: 1px solid #333 !important;
            color: #fff !important;
            border-radius: 8px !important;
        }
        yt-chip-cloud-chip-renderer[selected], yt-chip-cloud-chip-renderer:hover {
            background-color: #333 !important;
            color: #fff !important;
        }
        
        /* --- ARROW BUTTONS FIX (Black) --- */
        .navigation-container button, ytd-shorts-player-navigation-endpoint button, 
        #right-arrow-button, #left-arrow-button, 
        #right-arrow-button button, #left-arrow-button button { 
            background-color: #111111 !important; color: #ffffff !important; 
            border: 1px solid #333 !important; border-radius: 50% !important; 
        }

        /* --- MENUS & NOTIFICATION HEADER --- */
        ytd-multi-page-menu-renderer, .ytd-multi-page-menu-renderer,
        ytd-active-account-header-renderer, ytd-simple-menu-header-renderer,
        tp-yt-paper-listbox, ytd-menu-popup-renderer,
        #header.ytd-multi-page-menu-renderer,
        ytd-simple-menu-header-renderer {
            background-color: #111111 !important;
            border: 1px solid #333 !important;
        }

        /* --- SCROLLBAR --- */
        ::-webkit-scrollbar { width: 12px !important; background: #000 !important; }
        ::-webkit-scrollbar-track { background: #000 !important; }
        ::-webkit-scrollbar-thumb { background: #333 !important; border: 3px solid #000 !important; border-radius: 10px !important; }
        ::-webkit-scrollbar-thumb:hover { background: #555 !important; }

        /* --- SHORTS PLAYER FIX (THE BLACK BOX FIX) --- */
        ytd-shorts, #shorts-container, #shorts-inner-container,
        .reel-video-in-sequence-new, .reel-video-in-sequence-thumbnail, 
        ytd-reel-video-renderer, ytd-reel-video-renderer #player-container, 
        ytd-reel-video-renderer #movie_player, .html5-video-player, 
        .video-stream, #background.ytd-reel-video-renderer {
            background-color: #000000 !important; /* Pure Black for Seamless Cinema Look */
            border: none !important;
        }
        .html5-video-player .ytp-gradient-top, 
        .ytd-reel-video-renderer #player-container::before, 
        #shorts-player #player-container::before, 
        ytd-reel-video-renderer #player-container::before, 
        ytd-reel-player-overlay-renderer::before, 
        .reel-video-in-sequence-new::before, 
        .reel-video-in-sequence-thumbnail::before { 
            background: none !important; background-color: transparent !important; display: none !important; 
        }

        /* --- ENGAGEMENT PANELS --- */
        ytd-commentbox, #main.ytd-commentbox,
        ytd-backstage-post-dialog-renderer,
        #dialog-header.ytd-backstage-post-dialog-renderer,
        ytd-post-renderer,
        ytd-engagement-panel-section-list-renderer,
        ytd-engagement-panel-title-header-renderer,
        ytd-engagement-panel-title-header-renderer #header,
        #header.ytd-rich-grid-renderer {
            background-color: #000000 !important;
        }
    `,

    maroon: `
        html, body, ytd-app, #background, #masthead-background { background-color: #2b0a0a !important; } 
        #guide-content.ytd-app { background-color: #1a0505 !important; } 
        ytd-watch-flexy { --yt-spec-base-background: #2b0a0a !important; } 
        ytd-button-renderer.style-primary { background-color: #ff3131 !important; }

        #masthead-container, ytd-masthead, #masthead, ytd-feed-filter-chip-bar-renderer, #chips-wrapper, ytd-mini-guide-renderer, ytd-guide-renderer, #guide-content { background-color: #2b0a0a !important; }

        ytd-profile-header-renderer, ytd-profile-header-renderer #header, ytd-c4-tabbed-header-renderer, #channel-header, .tp-yt-app-header, #page-header-container, #page-header, yt-page-header-renderer, yt-page-header-view-model, ytd-tabbed-page-header { background-color: #2b0a0a !important; --yt-spec-base-background: #2b0a0a !important; }
        
        ytd-playlist-panel-renderer, ytd-playlist-panel-renderer #container, ytd-playlist-panel-renderer #header-contents, div.header.style-scope.ytd-playlist-panel-renderer, .playlist-items.ytd-playlist-panel-renderer { background-color: #2b0a0a !important; }

        yt-flexible-actions-view-model .yt-spec-button-shape-next--tonal, ytd-button-renderer.style-scope.ytd-simple-menu-header-renderer, .yt-spec-button-shape-next--tonal { background-color: #3d0e0e !important; color: #ffdada !important; border: 1px solid #5c1818 !important; }

        ytd-searchbox, #search-form, #container.ytd-searchbox, .ytSearchboxComponentInputBox { background-color: #3d0e0e !important; border: 1px solid #5c1818 !important; box-shadow: inset 0 1px 2px rgba(0,0,0,0.3) !important; } 
        input.ytSearchboxComponentInput { background-color: transparent !important; color: #ffdada !important; } 
        #voice-search-button, ytd-button-renderer#voice-search-button { background-color: #3d0e0e !important; }

        html body ytd-app ytd-masthead #search-icon-legacy, #search-icon-legacy { background: #3d0e0e !important; border: none !important; border-radius: 0 40px 40px 0 !important; margin-left: -2px !important; box-shadow: none !important; } 
        #masthead #end #buttons ytd-button-renderer, ytd-masthead #buttons ytd-button-renderer { background-color: #3d0e0e !important; border: 1px solid #5c1818 !important; border-radius: 40px !important; } 
        .ytd-profile-header-renderer ytd-button-renderer, ytd-profile-header-renderer #buttons ytd-button-renderer { background-color: #3d0e0e !important; border: 1px solid #5c1818 !important; border-radius: 40px !important; }

        .sbdd_b, .sbsb_a, .sbsb_c, .sbdd_a, ytd-search-suggestions-renderer, .ytSearchboxComponentSuggestionsContainer { background-color: #2b0a0a !important; border: 1px solid #5c1818 !important; } 
        .sbsb_c:hover { background-color: #4a0e0e !important; } .sbqs_c, .sbsb_d, .sbpqs_a { color: #ffdada !important; } .sbsb_i { color: #ff3131 !important; }

        yt-chip-cloud-chip-renderer { background-color: #3d0e0e !important; border: 1px solid #5c1818 !important; color: #ffdada !important; border-radius: 8px !important; } 
        yt-chip-cloud-chip-renderer[selected], yt-chip-cloud-chip-renderer:hover { background-color: #ff3131 !important; color: #fff !important; }
        
        .navigation-container button, ytd-shorts-player-navigation-endpoint button, #right-arrow-button, #left-arrow-button, #right-arrow-button button, #left-arrow-button button { background-color: #3d0e0e !important; color: #ffdada !important; border: 1px solid #5c1818 !important; border-radius: 50% !important; }

        ytd-multi-page-menu-renderer, .ytd-multi-page-menu-renderer, ytd-active-account-header-renderer, ytd-simple-menu-header-renderer, tp-yt-paper-listbox, ytd-menu-popup-renderer, #header.ytd-multi-page-menu-renderer, ytd-simple-menu-header-renderer { background-color: #2b0a0a !important; border: 1px solid #5c1818 !important; } 
        #secondary, #player-ads, ytd-ad-slot-renderer { background-color: transparent !important; }

        ::-webkit-scrollbar { width: 12px !important; background: #2b0a0a !important; } ::-webkit-scrollbar-track { background: #2b0a0a !important; } ::-webkit-scrollbar-thumb { background: #5c1818 !important; border: 3px solid #2b0a0a !important; border-radius: 10px !important; } ::-webkit-scrollbar-thumb:hover { background: #ff3131 !important; }

        ytd-shorts, #shorts-container, #shorts-inner-container, .reel-video-in-sequence-new, .reel-video-in-sequence-thumbnail, ytd-reel-video-renderer, ytd-reel-video-renderer #player-container, ytd-reel-video-renderer #movie_player, .html5-video-player, .video-stream, #background.ytd-reel-video-renderer { background-color: #000000 !important; border: none !important; }
        .html5-video-player .ytp-gradient-top, .ytd-reel-video-renderer #player-container::before, #shorts-player #player-container::before, ytd-reel-video-renderer #player-container::before, ytd-reel-player-overlay-renderer::before, .reel-video-in-sequence-new::before, .reel-video-in-sequence-thumbnail::before { background: none !important; background-color: transparent !important; display: none !important; }

        ytd-commentbox, #main.ytd-commentbox, ytd-backstage-post-dialog-renderer, #dialog-header.ytd-backstage-post-dialog-renderer, ytd-post-renderer, ytd-engagement-panel-section-list-renderer, ytd-engagement-panel-title-header-renderer, ytd-engagement-panel-title-header-renderer #header, #header.ytd-rich-grid-renderer { background-color: #2b0a0a !important; }
    `,

    darkblue: `
        html, body, ytd-app, #background, #masthead-background { background-color: #0f172a !important; } #guide-content.ytd-app { background-color: #080c16 !important; } ytd-watch-flexy { --yt-spec-base-background: #0f172a !important; }
        
        #masthead-container, ytd-masthead, #masthead, ytd-feed-filter-chip-bar-renderer, #chips-wrapper, ytd-mini-guide-renderer, ytd-guide-renderer, #guide-content { background-color: #0f172a !important; }

        ytd-profile-header-renderer, ytd-c4-tabbed-header-renderer, #channel-header, .tp-yt-app-header, #page-header-container, #page-header, yt-page-header-renderer, yt-page-header-view-model, ytd-tabbed-page-header { background-color: #0f172a !important; --yt-spec-base-background: #0f172a !important; }
        
        ytd-playlist-panel-renderer, ytd-playlist-panel-renderer #container, ytd-playlist-panel-renderer #header-contents, div.header.style-scope.ytd-playlist-panel-renderer, .playlist-items.ytd-playlist-panel-renderer { background-color: #0f172a !important; }

        yt-flexible-actions-view-model .yt-spec-button-shape-next--tonal, ytd-button-renderer.style-scope.ytd-simple-menu-header-renderer, .yt-spec-button-shape-next--tonal { background-color: #1e293b !important; color: #e2e8f0 !important; border: 1px solid #334155 !important; }

        ytd-searchbox, #search-form, #container.ytd-searchbox, .ytSearchboxComponentInputBox { background-color: #1e293b !important; border: 1px solid #334155 !important; } input.ytSearchboxComponentInput { background-color: transparent !important; color: #e2e8f0 !important; } #voice-search-button, ytd-button-renderer#voice-search-button { background-color: #1e293b !important; }

        html body ytd-app ytd-masthead #search-icon-legacy, #search-icon-legacy { background: #1e293b !important; border: none !important; border-radius: 0 40px 40px 0 !important; margin-left: -2px !important; box-shadow: none !important; } #masthead #end #buttons ytd-button-renderer, ytd-masthead #buttons ytd-button-renderer { background-color: #1e293b !important; border: 1px solid #334155 !important; border-radius: 40px !important; } .ytd-profile-header-renderer ytd-button-renderer, ytd-profile-header-renderer #buttons ytd-button-renderer { background-color: #1e293b !important; border: 1px solid #334155 !important; border-radius: 40px !important; }

        .sbdd_b, .sbsb_a, .sbsb_c, .sbdd_a, ytd-search-suggestions-renderer, .ytSearchboxComponentSuggestionsContainer { background-color: #0f172a !important; border: 1px solid #334155 !important; } .sbsb_c:hover { background-color: #1e293b !important; } .sbqs_c, .sbsb_d, .sbpqs_a { color: #e2e8f0 !important; }

        yt-chip-cloud-chip-renderer { background-color: #1e293b !important; border: 1px solid #334155 !important; color: #e2e8f0 !important; border-radius: 8px !important; } yt-chip-cloud-chip-renderer[selected], yt-chip-cloud-chip-renderer:hover { background-color: #3b82f6 !important; color: #fff !important; }
        .navigation-container button, ytd-shorts-player-navigation-endpoint button, #right-arrow-button, #left-arrow-button, #right-arrow-button button, #left-arrow-button button { background-color: #1e293b !important; color: #e2e8f0 !important; border: 1px solid #334155 !important; border-radius: 50% !important; }

        ytd-multi-page-menu-renderer, ytd-active-account-header-renderer, tp-yt-paper-listbox, ytd-simple-menu-header-renderer, #header.ytd-multi-page-menu-renderer, ytd-simple-menu-header-renderer { background-color: #0f172a !important; border: 1px solid #334155 !important; } #secondary, #player-ads { background-color: transparent !important; }

        ::-webkit-scrollbar { width: 12px !important; background: #0f172a !important; } ::-webkit-scrollbar-track { background: #0f172a !important; } ::-webkit-scrollbar-thumb { background: #334155 !important; border: 3px solid #0f172a !important; border-radius: 10px !important; } ::-webkit-scrollbar-thumb:hover { background: #3b82f6 !important; }

        ytd-shorts, #shorts-container, #shorts-inner-container, .reel-video-in-sequence-new, .reel-video-in-sequence-thumbnail, ytd-reel-video-renderer, ytd-reel-video-renderer #player-container, ytd-reel-video-renderer #movie_player, .html5-video-player, .video-stream, #background.ytd-reel-video-renderer { background-color: #000000 !important; border: none !important; } .html5-video-player .ytp-gradient-top, .ytd-reel-video-renderer #player-container::before, #shorts-player #player-container::before { background: none !important; display: none !important; }

        ytd-commentbox, #main.ytd-commentbox, ytd-backstage-post-dialog-renderer, #dialog-header.ytd-backstage-post-dialog-renderer, ytd-post-renderer, ytd-engagement-panel-section-list-renderer, ytd-engagement-panel-title-header-renderer, ytd-engagement-panel-title-header-renderer #header, #header.ytd-rich-grid-renderer { background-color: #0f172a !important; }
    `,

    darkgreen: `
        /* --- MAIN BACKGROUNDS --- */
        html, body, ytd-app, #background, #masthead-background { background-color: #051a05 !important; } #guide-content.ytd-app { background-color: #020f02 !important; } ytd-watch-flexy { --yt-spec-base-background: #051a05 !important; } ytd-button-renderer.style-primary, #progress { background-color: #10b981 !important; }

        /* --- HEADER & SIDEBAR --- */
        #masthead-container, ytd-masthead, #masthead, ytd-feed-filter-chip-bar-renderer, #chips-wrapper, ytd-mini-guide-renderer, ytd-guide-renderer, #guide-content { background-color: #051a05 !important; }

        /* --- PROFILE/YOU PAGE HEADER FIX --- */
        ytd-profile-header-renderer, ytd-c4-tabbed-header-renderer, #channel-header, .tp-yt-app-header, #page-header-container, #page-header, yt-page-header-renderer, yt-page-header-view-model, ytd-tabbed-page-header { background-color: #051a05 !important; --yt-spec-base-background: #051a05 !important; }
        
        /* --- PLAYLIST PANEL FIX --- */
        ytd-playlist-panel-renderer, ytd-playlist-panel-renderer #container, ytd-playlist-panel-renderer #header-contents, div.header.style-scope.ytd-playlist-panel-renderer, .playlist-items.ytd-playlist-panel-renderer { background-color: #051a05 !important; }

        /* --- PROFILE & MENU BUTTONS --- */
        yt-flexible-actions-view-model .yt-spec-button-shape-next--tonal, ytd-button-renderer.style-scope.ytd-simple-menu-header-renderer, .yt-spec-button-shape-next--tonal { background-color: #0a330a !important; color: #e6f5e6 !important; border: 1px solid #0f420f !important; }

        /* --- SEARCH BAR --- */
        ytd-searchbox, #search-form, #container.ytd-searchbox, .ytSearchboxComponentInputBox { background-color: #0a330a !important; border: 1px solid #0f420f !important; } input.ytSearchboxComponentInput { background-color: transparent !important; color: #e6f5e6 !important; } #voice-search-button, ytd-button-renderer#voice-search-button { background-color: #0a330a !important; }

        /* --- BUTTONS FIX --- */
        html body ytd-app ytd-masthead #search-icon-legacy, #search-icon-legacy { background: #0a330a !important; border: none !important; border-radius: 0 40px 40px 0 !important; margin-left: -2px !important; box-shadow: none !important; } #masthead #end #buttons ytd-button-renderer, ytd-masthead #buttons ytd-button-renderer { background-color: #0a330a !important; border: 1px solid #0f420f !important; border-radius: 40px !important; } .ytd-profile-header-renderer ytd-button-renderer, ytd-profile-header-renderer #buttons ytd-button-renderer { background-color: #0a330a !important; border: 1px solid #0f420f !important; border-radius: 40px !important; }

        /* --- SEARCH HISTORY DROPDOWN --- */
        .sbdd_b, .sbsb_a, .sbsb_c, .sbdd_a, ytd-search-suggestions-renderer, .ytSearchboxComponentSuggestionsContainer { background-color: #051a05 !important; border: 1px solid #0f420f !important; } .sbsb_c:hover { background-color: #0a330a !important; } .sbqs_c, .sbsb_d, .sbpqs_a { color: #e6f5e6 !important; }

        /* --- TOPIC CHIPS & ARROWS --- */
        yt-chip-cloud-chip-renderer { background-color: #0a330a !important; border: 1px solid #0f420f !important; color: #e6f5e6 !important; border-radius: 8px !important; } yt-chip-cloud-chip-renderer[selected], yt-chip-cloud-chip-renderer:hover { background-color: #10b981 !important; color: #fff !important; }
        .navigation-container button, ytd-shorts-player-navigation-endpoint button, #right-arrow-button, #left-arrow-button, #right-arrow-button button, #left-arrow-button button { background-color: #0a330a !important; color: #e6f5e6 !important; border: 1px solid #0f420f !important; border-radius: 50% !important; }

        /* --- MENUS & NOTIFICATION HEADER --- */
        ytd-multi-page-menu-renderer, ytd-active-account-header-renderer, tp-yt-paper-listbox, ytd-simple-menu-header-renderer, #header.ytd-multi-page-menu-renderer, ytd-simple-menu-header-renderer { background-color: #051a05 !important; border: 1px solid #14532d !important; }

        /* --- SCROLLBAR --- */
        ::-webkit-scrollbar { width: 12px !important; background: #051a05 !important; } ::-webkit-scrollbar-track { background: #051a05 !important; } ::-webkit-scrollbar-thumb { background: #14532d !important; border: 3px solid #051a05 !important; border-radius: 10px !important; } ::-webkit-scrollbar-thumb:hover { background: #10b981 !important; }

        /* --- SHORTS PLAYER FIX (CINEMA MODE - BLACK) --- */
        ytd-shorts, #shorts-container, #shorts-inner-container, .reel-video-in-sequence-new, .reel-video-in-sequence-thumbnail, ytd-reel-video-renderer, ytd-reel-video-renderer #player-container, ytd-reel-video-renderer #movie_player, .html5-video-player, .video-stream, #background.ytd-reel-video-renderer { background-color: #000000 !important; border: none !important; } .html5-video-player .ytp-gradient-top, .ytd-reel-video-renderer #player-container::before, #shorts-player #player-container::before { background: none !important; display: none !important; }

        /* --- ENGAGEMENT PANELS --- */
        ytd-commentbox, #main.ytd-commentbox, ytd-backstage-post-dialog-renderer, #dialog-header.ytd-backstage-post-dialog-renderer, ytd-post-renderer, ytd-engagement-panel-section-list-renderer, ytd-engagement-panel-title-header-renderer, ytd-engagement-panel-title-header-renderer #header, #header.ytd-rich-grid-renderer { background-color: #051a05 !important; }
    `,

    purple: `
        /* --- MAIN BACKGROUNDS --- */
        html, body, ytd-app, #background, #masthead-background { background-color: #1a0b2e !important; } #guide-content.ytd-app { background-color: #11001c !important; } ytd-watch-flexy { --yt-spec-base-background: #1a0b2e !important; } ytd-button-renderer.style-primary, #progress { background-color: #a855f7 !important; }

        /* --- HEADER, CHIPS & SIDEBAR --- */
        #masthead-container, ytd-masthead, #masthead, ytd-feed-filter-chip-bar-renderer, #chips-wrapper, ytd-mini-guide-renderer, ytd-guide-renderer, #guide-content { background-color: #1a0b2e !important; }

        /* --- PROFILE/YOU PAGE HEADER FIX --- */
        ytd-profile-header-renderer, ytd-c4-tabbed-header-renderer, #channel-header, .tp-yt-app-header, #page-header-container, #page-header, yt-page-header-renderer, yt-page-header-view-model, ytd-tabbed-page-header { background-color: #1a0b2e !important; --yt-spec-base-background: #1a0b2e !important; }
        
        /* --- PLAYLIST PANEL FIX --- */
        ytd-playlist-panel-renderer, ytd-playlist-panel-renderer #container, ytd-playlist-panel-renderer #header-contents, div.header.style-scope.ytd-playlist-panel-renderer, .playlist-items.ytd-playlist-panel-renderer { background-color: #1a0b2e !important; }

        /* --- PROFILE & MENU BUTTONS --- */
        yt-flexible-actions-view-model .yt-spec-button-shape-next--tonal, ytd-button-renderer.style-scope.ytd-simple-menu-header-renderer, .yt-spec-button-shape-next--tonal { background-color: #2f1452 !important; color: #f3e8ff !important; border: 1px solid #581c87 !important; }

        /* --- SEARCH BAR --- */
        ytd-searchbox, #search-form, #container.ytd-searchbox, .ytSearchboxComponentInputBox { background-color: #2f1452 !important; border: 1px solid #581c87 !important; } input.ytSearchboxComponentInput { background-color: transparent !important; color: #f3e8ff !important; } #voice-search-button, ytd-button-renderer#voice-search-button { background-color: #2f1452 !important; }

        /* --- BUTTONS FIX --- */
        html body ytd-app ytd-masthead #search-icon-legacy, #search-icon-legacy { background: #2f1452 !important; border: none !important; border-radius: 0 40px 40px 0 !important; margin-left: -2px !important; box-shadow: none !important; } #masthead #end #buttons ytd-button-renderer, ytd-masthead #buttons ytd-button-renderer { background-color: #2f1452 !important; border: 1px solid #581c87 !important; border-radius: 40px !important; } .ytd-profile-header-renderer ytd-button-renderer, ytd-profile-header-renderer #buttons ytd-button-renderer { background-color: #2f1452 !important; border: 1px solid #581c87 !important; border-radius: 40px !important; }

        /* --- SEARCH HISTORY DROPDOWN --- */
        .sbdd_b, .sbsb_a, .sbsb_c, .sbdd_a, ytd-search-suggestions-renderer, .ytSearchboxComponentSuggestionsContainer { background-color: #1a0b2e !important; border: 1px solid #581c87 !important; } .sbsb_c:hover { background-color: #2f1452 !important; } .sbqs_c, .sbsb_d, .sbpqs_a { color: #f3e8ff !important; }

        /* --- TOPIC CHIPS & ARROWS --- */
        yt-chip-cloud-chip-renderer { background-color: #2f1452 !important; border: 1px solid #581c87 !important; color: #f3e8ff !important; border-radius: 8px !important; } yt-chip-cloud-chip-renderer[selected], yt-chip-cloud-chip-renderer:hover { background-color: #a855f7 !important; color: #fff !important; }
        .navigation-container button, ytd-shorts-player-navigation-endpoint button, #right-arrow-button, #left-arrow-button, #right-arrow-button button, #left-arrow-button button { background-color: #2f1452 !important; color: #f3e8ff !important; border: 1px solid #581c87 !important; border-radius: 50% !important; }

        /* --- MENUS & NOTIFICATION HEADER --- */
        ytd-multi-page-menu-renderer, ytd-active-account-header-renderer, tp-yt-paper-listbox, ytd-simple-menu-header-renderer, #header.ytd-multi-page-menu-renderer, ytd-simple-menu-header-renderer { background-color: #1a0b2e !important; border: 1px solid #581c87 !important; }

        /* --- SCROLLBAR --- */
        ::-webkit-scrollbar { width: 12px !important; background: #1a0b2e !important; } ::-webkit-scrollbar-track { background: #1a0b2e !important; } ::-webkit-scrollbar-thumb { background: #581c87 !important; border: 3px solid #1a0b2e !important; border-radius: 10px !important; } ::-webkit-scrollbar-thumb:hover { background: #a855f7 !important; }

        /* --- SHORTS PLAYER FIX (CINEMA MODE - BLACK) --- */
        ytd-shorts, #shorts-container, #shorts-inner-container, .reel-video-in-sequence-new, .reel-video-in-sequence-thumbnail, ytd-reel-video-renderer, ytd-reel-video-renderer #player-container, ytd-reel-video-renderer #movie_player, .html5-video-player, .video-stream, #background.ytd-reel-video-renderer { background-color: #000000 !important; border: none !important; } .html5-video-player .ytp-gradient-top, .ytd-reel-video-renderer #player-container::before, #shorts-player #player-container::before { background: none !important; display: none !important; }

        /* --- ENGAGEMENT PANELS --- */
        ytd-commentbox, #main.ytd-commentbox, ytd-backstage-post-dialog-renderer, #dialog-header.ytd-backstage-post-dialog-renderer, ytd-post-renderer, ytd-engagement-panel-section-list-renderer, ytd-engagement-panel-title-header-renderer, ytd-engagement-panel-title-header-renderer #header, #header.ytd-rich-grid-renderer { background-color: #1a0b2e !important; }
    `,

    babypink: `
        /* --- MAIN BACKGROUNDS --- */
        html, body, ytd-app, #background, #masthead-background { background-color: #2b1a1f !important; } #guide-content.ytd-app { background-color: #1a0f12 !important; } ytd-watch-flexy { --yt-spec-base-background: #2b1a1f !important; } ytd-button-renderer.style-primary { background-color: #ff99ac !important; }

        /* --- HEADER, CHIPS & SIDEBAR --- */
        #masthead-container, ytd-masthead, #masthead, ytd-feed-filter-chip-bar-renderer, #chips-wrapper, ytd-mini-guide-renderer, ytd-guide-renderer, #guide-content { background-color: #2b1a1f !important; }

        /* --- PROFILE/YOU PAGE HEADER FIX --- */
        ytd-profile-header-renderer, ytd-profile-header-renderer #header, ytd-c4-tabbed-header-renderer, #channel-header, .tp-yt-app-header, #page-header-container, #page-header, yt-page-header-renderer, yt-page-header-view-model, ytd-tabbed-page-header { background-color: #2b1a1f !important; --yt-spec-base-background: #2b1a1f !important; }
        
        /* --- PLAYLIST PANEL FIX --- */
        ytd-playlist-panel-renderer, ytd-playlist-panel-renderer #container, ytd-playlist-panel-renderer #header-contents, div.header.style-scope.ytd-playlist-panel-renderer, .playlist-items.ytd-playlist-panel-renderer { background-color: #2b1a1f !important; }

        /* --- PROFILE & MENU BUTTONS --- */
        yt-flexible-actions-view-model .yt-spec-button-shape-next--tonal, ytd-button-renderer.style-scope.ytd-simple-menu-header-renderer, .yt-spec-button-shape-next--tonal { background-color: #3d262b !important; color: #ffdada !important; border: 1px solid #5c3a41 !important; }

        /* --- SEARCH BAR --- */
        ytd-searchbox, #search-form, #container.ytd-searchbox, .ytSearchboxComponentInputBox { background-color: #3d262b !important; border: 1px solid #5c3a41 !important; box-shadow: inset 0 1px 2px rgba(0,0,0,0.3) !important; } input.ytSearchboxComponentInput { background-color: transparent !important; color: #ffdada !important; } #voice-search-button, ytd-button-renderer#voice-search-button { background-color: #3d262b !important; }

        /* --- BUTTONS FIX --- */
        html body ytd-app ytd-masthead #search-icon-legacy, #search-icon-legacy { background: #3d262b !important; border: none !important; border-radius: 0 40px 40px 0 !important; margin-left: -2px !important; box-shadow: none !important; } #masthead #end #buttons ytd-button-renderer, ytd-masthead #buttons ytd-button-renderer { background-color: #3d262b !important; border: 1px solid #5c3a41 !important; border-radius: 40px !important; } .ytd-profile-header-renderer ytd-button-renderer, ytd-profile-header-renderer #buttons ytd-button-renderer { background-color: #3d262b !important; border: 1px solid #5c3a41 !important; border-radius: 40px !important; }

        /* --- SEARCH HISTORY DROPDOWN --- */
        .sbdd_b, .sbsb_a, .sbsb_c, .sbdd_a, ytd-search-suggestions-renderer, .ytSearchboxComponentSuggestionsContainer { background-color: #2b1a1f !important; border: 1px solid #5c3a41 !important; } .sbsb_c:hover { background-color: #4a2e35 !important; } .sbqs_c, .sbsb_d, .sbpqs_a { color: #ffdada !important; } .sbsb_i { color: #ff99ac !important; }

        /* --- TOPIC CHIPS & ARROWS --- */
        yt-chip-cloud-chip-renderer { background-color: #3d262b !important; border: 1px solid #5c3a41 !important; color: #ffdada !important; border-radius: 8px !important; } yt-chip-cloud-chip-renderer[selected], yt-chip-cloud-chip-renderer:hover { background-color: #ff99ac !important; color: #fff !important; }
        .navigation-container button, ytd-shorts-player-navigation-endpoint button, #right-arrow-button, #left-arrow-button, #right-arrow-button button, #left-arrow-button button { background-color: #3d262b !important; color: #ffdada !important; border: 1px solid #5c3a41 !important; border-radius: 50% !important; }

        /* --- MENUS & NOTIFICATION HEADER --- */
        ytd-multi-page-menu-renderer, ytd-active-account-header-renderer, tp-yt-paper-listbox, ytd-simple-menu-header-renderer, #header.ytd-multi-page-menu-renderer, ytd-simple-menu-header-renderer { background-color: #2b1a1f !important; border: 1px solid #5c3a41 !important; } #secondary, #player-ads { background-color: transparent !important; }

        /* --- SCROLLBAR --- */
        ::-webkit-scrollbar { width: 12px !important; background: #2b1a1f !important; } ::-webkit-scrollbar-track { background: #2b1a1f !important; } ::-webkit-scrollbar-thumb { background: #5c3a41 !important; border: 3px solid #2b1a1f !important; border-radius: 10px !important; } ::-webkit-scrollbar-thumb:hover { background: #ff99ac !important; }

        /* --- SHORTS PLAYER FIX (CINEMA MODE - BLACK) --- */
        ytd-shorts, #shorts-container, #shorts-inner-container, .reel-video-in-sequence-new, .reel-video-in-sequence-thumbnail, ytd-reel-video-renderer, ytd-reel-video-renderer #player-container, ytd-reel-video-renderer #movie_player, .html5-video-player, .video-stream, #background.ytd-reel-video-renderer { background-color: #000000 !important; border: none !important; } .html5-video-player .ytp-gradient-top, .ytd-reel-video-renderer #player-container::before, #shorts-player #player-container::before { background: none !important; display: none !important; }

        /* --- ENGAGEMENT PANELS --- */
        ytd-commentbox, #main.ytd-commentbox, ytd-backstage-post-dialog-renderer, #dialog-header.ytd-backstage-post-dialog-renderer, ytd-post-renderer, ytd-engagement-panel-section-list-renderer, ytd-engagement-panel-title-header-renderer, ytd-engagement-panel-title-header-renderer #header, #header.ytd-rich-grid-renderer { background-color: #2b1a1f !important; }
    `,

    brightpink: `
        /* --- MAIN BACKGROUNDS --- */
        html, body, ytd-app, #background, #masthead-background { background-color: #330015 !important; } #guide-content.ytd-app { background-color: #22000e !important; } ytd-watch-flexy { --yt-spec-base-background: #330015 !important; } ytd-button-renderer.style-primary { background-color: #ff0055 !important; }

        /* --- HEADER, CHIPS & SIDEBAR --- */
        #masthead-container, ytd-masthead, #masthead, ytd-feed-filter-chip-bar-renderer, #chips-wrapper, ytd-mini-guide-renderer, ytd-guide-renderer, #guide-content { background-color: #330015 !important; }

        /* --- PROFILE/YOU PAGE HEADER FIX --- */
        ytd-profile-header-renderer, ytd-profile-header-renderer #header, ytd-c4-tabbed-header-renderer, #channel-header, .tp-yt-app-header, #page-header-container, #page-header, yt-page-header-renderer, yt-page-header-view-model, ytd-tabbed-page-header { background-color: #330015 !important; --yt-spec-base-background: #330015 !important; }
        
        /* --- PLAYLIST PANEL FIX --- */
        ytd-playlist-panel-renderer, ytd-playlist-panel-renderer #container, ytd-playlist-panel-renderer #header-contents, div.header.style-scope.ytd-playlist-panel-renderer, .playlist-items.ytd-playlist-panel-renderer { background-color: #330015 !important; }

        /* --- PROFILE & MENU BUTTONS --- */
        yt-flexible-actions-view-model .yt-spec-button-shape-next--tonal, ytd-button-renderer.style-scope.ytd-simple-menu-header-renderer, .yt-spec-button-shape-next--tonal { background-color: #590024 !important; color: #ffd9ec !important; border: 1px solid #800033 !important; }

        /* --- SEARCH BAR --- */
        ytd-searchbox, #search-form, #container.ytd-searchbox, .ytSearchboxComponentInputBox { background-color: #590024 !important; border: 1px solid #800033 !important; box-shadow: inset 0 1px 2px rgba(0,0,0,0.3) !important; } input.ytSearchboxComponentInput { background-color: transparent !important; color: #ffd9ec !important; } #voice-search-button, ytd-button-renderer#voice-search-button { background-color: #590024 !important; }

        /* --- BUTTONS FIX --- */
        html body ytd-app ytd-masthead #search-icon-legacy, #search-icon-legacy { background: #590024 !important; border: none !important; border-radius: 0 40px 40px 0 !important; margin-left: -2px !important; box-shadow: none !important; } #masthead #end #buttons ytd-button-renderer, ytd-masthead #buttons ytd-button-renderer { background-color: #590024 !important; border: 1px solid #800033 !important; border-radius: 40px !important; } .ytd-profile-header-renderer ytd-button-renderer, ytd-profile-header-renderer #buttons ytd-button-renderer { background-color: #590024 !important; border: 1px solid #800033 !important; border-radius: 40px !important; }

        /* --- SEARCH HISTORY DROPDOWN --- */
        .sbdd_b, .sbsb_a, .sbsb_c, .sbdd_a, ytd-search-suggestions-renderer, .ytSearchboxComponentSuggestionsContainer { background-color: #330015 !important; border: 1px solid #800033 !important; } .sbsb_c:hover { background-color: #800033 !important; } .sbqs_c, .sbsb_d, .sbpqs_a { color: #ffd9ec !important; } .sbsb_i { color: #ff0055 !important; }

        /* --- TOPIC CHIPS & ARROWS --- */
        yt-chip-cloud-chip-renderer { background-color: #590024 !important; border: 1px solid #800033 !important; color: #ffd9ec !important; border-radius: 8px !important; } yt-chip-cloud-chip-renderer[selected], yt-chip-cloud-chip-renderer:hover { background-color: #ff0055 !important; color: #fff !important; }
        .navigation-container button, ytd-shorts-player-navigation-endpoint button, #right-arrow-button, #left-arrow-button, #right-arrow-button button, #left-arrow-button button { background-color: #590024 !important; color: #ffd9ec !important; border: 1px solid #800033 !important; border-radius: 50% !important; }

        /* --- MENUS & NOTIFICATION HEADER --- */
        ytd-multi-page-menu-renderer, ytd-active-account-header-renderer, tp-yt-paper-listbox, ytd-simple-menu-header-renderer, #header.ytd-multi-page-menu-renderer, ytd-simple-menu-header-renderer { background-color: #330015 !important; border: 1px solid #800033 !important; } #secondary, #player-ads { background-color: transparent !important; }

        /* --- SCROLLBAR --- */
        ::-webkit-scrollbar { width: 12px !important; background: #330015 !important; } ::-webkit-scrollbar-track { background: #330015 !important; } ::-webkit-scrollbar-thumb { background: #800033 !important; border: 3px solid #330015 !important; border-radius: 10px !important; } ::-webkit-scrollbar-thumb:hover { background: #ff0055 !important; }

        /* --- SHORTS PLAYER FIX (CINEMA MODE - BLACK) --- */
        ytd-shorts, #shorts-container, #shorts-inner-container, .reel-video-in-sequence-new, .reel-video-in-sequence-thumbnail, ytd-reel-video-renderer, ytd-reel-video-renderer #player-container, ytd-reel-video-renderer #movie_player, .html5-video-player, .video-stream, #background.ytd-reel-video-renderer { background-color: #000000 !important; border: none !important; } .html5-video-player .ytp-gradient-top, .ytd-reel-video-renderer #player-container::before, #shorts-player #player-container::before { background: none !important; display: none !important; }

        /* --- ENGAGEMENT PANELS --- */
        ytd-commentbox, #main.ytd-commentbox, ytd-backstage-post-dialog-renderer, #dialog-header.ytd-backstage-post-dialog-renderer, ytd-post-renderer, ytd-engagement-panel-section-list-renderer, ytd-engagement-panel-title-header-renderer, ytd-engagement-panel-title-header-renderer #header, #header.ytd-rich-grid-renderer { background-color: #330015 !important; }
    `
};

function applyTheme(themeName) {
    const existing = document.getElementById("yt-super-theme-style");
    if (existing) existing.remove();

    localStorage.setItem("yt_super_theme", themeName);

    document.querySelectorAll(".ys-theme-btn").forEach(btn => {
        btn.classList.remove("active");
        if(btn.dataset.theme === themeName) btn.classList.add("active");
    });

    if (THEME_STYLES[themeName]) {
        const style = document.createElement("style");
        style.id = "yt-super-theme-style";
        style.innerHTML = THEME_STYLES[themeName];
        document.head.appendChild(style);
    } else if (themeName === 'custom') {
    const savedCSS = localStorage.getItem("yt_super_custom_css");
    if (savedCSS) {
        const style = document.createElement("style");
        style.id = "yt-super-custom-theme-style";
        style.innerHTML = savedCSS;
        document.head.appendChild(style);
    }
}

}

// Function to apply a custom color theme
function applyCustomColor(baseColor) {
    const adjustColor = (color, amount) => {
        return '#' + color.replace(/^#/, '').replace(/../g, color => ('0' + Math.min(255, Math.max(0, parseInt(color, 16) + amount)).toString(16)).substr(-2));
    };

    const bg = baseColor;
    const secondary = adjustColor(baseColor, 20); 
    const border = adjustColor(baseColor, 40);
    const text = '#ffffff';

    const customCSS = `
        html, body, ytd-app, #background, #masthead-background { background-color: ${bg} !important; } #guide-content.ytd-app { background-color: ${adjustColor(bg, -10)} !important; } ytd-watch-flexy { --yt-spec-base-background: ${bg} !important; } ytd-button-renderer.style-primary { background-color: ${border} !important; }
        
        #masthead-container, ytd-masthead, #masthead, ytd-feed-filter-chip-bar-renderer, #chips-wrapper, ytd-mini-guide-renderer, ytd-guide-renderer, #guide-content { background-color: ${bg} !important; }

        ytd-profile-header-renderer, ytd-profile-header-renderer #header, ytd-c4-tabbed-header-renderer, #channel-header, .tp-yt-app-header, #page-header-container, #page-header, yt-page-header-renderer, yt-page-header-view-model, ytd-tabbed-page-header { background-color: ${bg} !important; --yt-spec-base-background: ${bg} !important; }
        
        ytd-playlist-panel-renderer, ytd-playlist-panel-renderer #container, ytd-playlist-panel-renderer #header-contents, div.header.style-scope.ytd-playlist-panel-renderer, .playlist-items.ytd-playlist-panel-renderer { background-color: ${bg} !important; }

        yt-flexible-actions-view-model .yt-spec-button-shape-next--tonal, ytd-button-renderer.style-scope.ytd-simple-menu-header-renderer, .yt-spec-button-shape-next--tonal { background-color: ${secondary} !important; color: ${text} !important; border: 1px solid ${border} !important; }

        ytd-searchbox, #search-form, #container.ytd-searchbox, .ytSearchboxComponentInputBox { background-color: ${secondary} !important; border: 1px solid ${border} !important; box-shadow: inset 0 1px 2px rgba(0,0,0,0.3) !important; } input.ytSearchboxComponentInput { background-color: transparent !important; color: ${text} !important; } #voice-search-button, ytd-button-renderer#voice-search-button { background-color: ${secondary} !important; }

        html body ytd-app ytd-masthead #search-icon-legacy, #search-icon-legacy { background: ${secondary} !important; border: none !important; border-radius: 0 40px 40px 0 !important; margin-left: -2px !important; box-shadow: none !important; } #masthead #end #buttons ytd-button-renderer, ytd-masthead #buttons ytd-button-renderer { background-color: ${secondary} !important; border: 1px solid ${border} !important; border-radius: 40px !important; } .ytd-profile-header-renderer ytd-button-renderer, ytd-profile-header-renderer #buttons ytd-button-renderer { background-color: ${secondary} !important; border: 1px solid ${border} !important; border-radius: 40px !important; }

        .sbdd_b, .sbsb_a, .sbsb_c, .sbdd_a, ytd-search-suggestions-renderer, .ytSearchboxComponentSuggestionsContainer { background-color: ${bg} !important; border: 1px solid ${border} !important; } .sbsb_c:hover { background-color: ${secondary} !important; } .sbqs_c, .sbsb_d, .sbpqs_a { color: ${text} !important; } .sbsb_i { color: ${border} !important; }

        yt-chip-cloud-chip-renderer { background-color: ${secondary} !important; border: 1px solid ${border} !important; color: ${text} !important; border-radius: 8px !important; } yt-chip-cloud-chip-renderer[selected], yt-chip-cloud-chip-renderer:hover { background-color: ${border} !important; color: #fff !important; }

        .navigation-container button, ytd-shorts-player-navigation-endpoint button, #right-arrow-button, #left-arrow-button, #right-arrow-button button, #left-arrow-button button { background-color: ${secondary} !important; color: ${text} !important; border: 1px solid ${border} !important; border-radius: 50% !important; }

        ytd-multi-page-menu-renderer, ytd-active-account-header-renderer, tp-yt-paper-listbox, ytd-simple-menu-header-renderer, #header.ytd-multi-page-menu-renderer, ytd-simple-menu-header-renderer { background-color: ${bg} !important; border: 1px solid ${border} !important; } #secondary, #player-ads { background-color: transparent !important; }

        ::-webkit-scrollbar { width: 12px !important; background: ${bg} !important; } ::-webkit-scrollbar-track { background: ${bg} !important; } ::-webkit-scrollbar-thumb { background: ${border} !important; border: 3px solid ${bg} !important; border-radius: 10px !important; } ::-webkit-scrollbar-thumb:hover { background: ${border} !important; }

        ytd-shorts, #shorts-container, #shorts-inner-container, .reel-video-in-sequence-new, .reel-video-in-sequence-thumbnail, ytd-reel-video-renderer, ytd-reel-video-renderer #player-container, ytd-reel-video-renderer #movie_player, .html5-video-player, .video-stream, #background.ytd-reel-video-renderer { background-color: #000000 !important; border: none !important; } .html5-video-player .ytp-gradient-top, .ytd-reel-video-renderer #player-container::before, #shorts-player #player-container::before { background: none !important; display: none !important; }

        ytd-commentbox, #main.ytd-commentbox, ytd-backstage-post-dialog-renderer, #dialog-header.ytd-backstage-post-dialog-renderer, ytd-post-renderer, ytd-engagement-panel-section-list-renderer, ytd-engagement-panel-title-header-renderer, ytd-engagement-panel-title-header-renderer #header, #header.ytd-rich-grid-renderer { background-color: ${bg} !important; }
    `;
    localStorage.setItem("yt_super_custom_css", customCSS);
    const existing = document.getElementById("yt-super-theme-style");
    if (existing) existing.remove();
    const style = document.createElement("style");
    style.id = "yt-super-theme-style";
    style.innerHTML = customCSS;
    document.head.appendChild(style);
    
    // SAVE CUSTOM COLOR FOR PERSISTENCE
    localStorage.setItem("yt_super_theme", "custom");
    localStorage.setItem("yt_super_custom_color", baseColor);
}
document.querySelectorAll(".ys-theme-btn").forEach(btn => btn.classList.remove("active"));
document.querySelector("#ys-color-picker").parentElement.classList.add("active");
// ======================================================
// 🌈 FINAL FIX — CUSTOM COLOR PERSISTENCE ON ALL PAGES
// ======================================================

function reapplyThemeIfNeeded() {
    const theme = localStorage.getItem("yt_super_theme");

    if (theme === "custom") {
        applyTheme("custom");
    } else if (theme) {
        applyTheme(theme);
    }
}

let lastURL = location.href;
setInterval(() => {
    if (location.href !== lastURL) {
        lastURL = location.href;
        setTimeout(reapplyThemeIfNeeded, 500);
    }
}, 400);
