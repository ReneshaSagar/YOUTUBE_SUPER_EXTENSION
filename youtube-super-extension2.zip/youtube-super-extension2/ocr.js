// NOTE: Ideally, keep API keys in a secure backend. For this extension demo, it's here.
const GEMINI_API_KEY = "AIzaSyDjYyIMUzGnxx6BOxfZJdqmOwxDlt_UEVc"; 

async function captureVideoFrame() {
  const video = document.querySelector("video");
  if (!video) throw new Error("No video found!");

  const canvas = document.createElement("canvas");
  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;
  const ctx = canvas.getContext("2d");
  
  // Draw video to canvas
  try {
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL("image/jpeg", 0.7); // Return base64
  } catch (e) {
    alert("Security Restriction: Cannot capture protected video content directly.");
    throw e;
  }
}

async function runOCR() {
  const btn = document.getElementById("ocr-btn");
  const originalText = btn.innerHTML;
  
  try {
    btn.innerHTML = "📸 Capturing...";
    const base64Image = await captureVideoFrame();
    
    btn.innerHTML = "🤖 Analyzing (Gemini)...";
    
    // Clean base64 string
    const imagePart = base64Image.split(",")[1];

    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${GEMINI_API_KEY}`;
    
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{
          parts: [
            { text: "Extract all legible text from this video frame. Return ONLY the text, no explanation." },
            { inline_data: { mime_type: "image/jpeg", data: imagePart } }
          ]
        }]
      })
    });

    const data = await response.json();
    const extractedText = data.candidates?.[0]?.content?.parts?.[0]?.text;

    if (extractedText) {
      await navigator.clipboard.writeText(extractedText);
      alert("✨ Text Copied to Clipboard:\n\n" + extractedText);
    } else {
      throw new Error("No text found.");
    }

  } catch (err) {
    console.error(err);
    alert("OCR Failed: " + err.message);
  } finally {
    btn.innerHTML = originalText;
  }
}