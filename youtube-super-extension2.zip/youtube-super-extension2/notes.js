// Functionality moved to ui.js
// This file can be left empty to prevent the old floating notes from appearing.