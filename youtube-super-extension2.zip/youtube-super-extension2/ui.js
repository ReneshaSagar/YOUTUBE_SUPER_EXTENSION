function buildUI() {
  if (document.getElementById("yt-super-panel")) return;

  const panel = document.createElement("div");
  panel.id = "yt-super-panel";
  
  // New HTML Structure with Bright Pink and Rainbow
  panel.innerHTML = `
    <div class="ys-header">
      <div class="ys-title">YT Super Mode 🚀</div>
      <div id="ys-close-btn">✕</div>
    </div>

    <div class="ys-section-title">Aesthetic Themes</div>
    <div class="ys-themes-grid">
      <button class="ys-theme-btn t-black" data-theme="black" title="Black Mode"></button>
      <button class="ys-theme-btn t-maroon" data-theme="maroon" title="Maroon Mode"></button>
      <button class="ys-theme-btn t-blue" data-theme="darkblue" title="Deep Blue Mode"></button>
      <button class="ys-theme-btn t-green" data-theme="darkgreen" title="Forest Green Mode"></button>
      <button class="ys-theme-btn t-purple" data-theme="purple" title="Purple Mode"></button>
      <button class="ys-theme-btn t-babypink" data-theme="babypink" title="Baby Pink Mode"></button>
      <button class="ys-theme-btn t-brightpink" data-theme="brightpink" title="Bright Pink Mode"></button>
      
      <div class="ys-theme-btn t-rainbow" title="Custom Color (Rainbow)">
        <input type="color" id="ys-color-picker" value="#ff0000">
      </div>
    </div>

    <div class="ys-section-title">Playback Speed</div>
    <div class="ys-speed-wrapper">
      <input type="range" id="super-speed" min="0.25" max="3.0" step="0.05" value="1.0">
      <span id="speed-display" class="ys-speed-val">1.0x</span>
    </div>

    <div class="ys-section-title">Digital Notes</div>
    <textarea id="yt-notes-area" placeholder="Notes save automatically here..."></textarea>

    <button id="ocr-btn" class="ys-hero-btn">
      <span>📸</span> Copy Text From Screen
    </button>
  `;

  document.body.appendChild(panel);

  // Floating Toggle Button
  const toggle = document.createElement("div");
  toggle.id = "yt-panel-toggle";
  toggle.innerHTML = "🚀";
  toggle.onclick = () => {
    panel.classList.add("show");
    toggle.style.transform = "scale(0)";
  };
  document.body.appendChild(toggle);

  // Close Logic
  document.getElementById("ys-close-btn").onclick = () => {
    panel.classList.remove("show");
    setTimeout(() => {
        document.getElementById("yt-panel-toggle").style.transform = "scale(1)";
    }, 300);
  };

  // --- EVENTS ---

  // 1. Theme Click (Standard Buttons)
  panel.querySelectorAll(".ys-theme-btn[data-theme]").forEach(btn => {
    btn.onclick = () => applyTheme(btn.dataset.theme);
  });

  // 2. Custom Rainbow Color Picker Logic
  const colorPicker = document.getElementById("ys-color-picker");
  // Restore saved color to picker on load so it matches your persistent theme
  const savedColor = localStorage.getItem("yt_super_custom_color");
  if (savedColor) colorPicker.value = savedColor;

  if (colorPicker) {
      colorPicker.oninput = (e) => {
          if (typeof applyCustomColor === "function") {
              applyCustomColor(e.target.value);
              
              // Remove active class from other buttons
              panel.querySelectorAll(".ys-theme-btn").forEach(btn => btn.classList.remove("active"));
              colorPicker.parentElement.classList.add("active");
          }
      };
  }

  // 3. Speed Slider
  const slider = document.getElementById("super-speed");
  const speedDisplay = document.getElementById("speed-display");
  
  slider.oninput = (e) => {
    const val = parseFloat(e.target.value);
    const video = document.querySelector("video");
    if (video) video.playbackRate = val;
    speedDisplay.innerText = val.toFixed(2) + "x";
    localStorage.setItem("yt_super_speed", val);
  };

  // Restore Speed
  const savedSpeed = localStorage.getItem("yt_super_speed");
  if (savedSpeed) {
    slider.value = savedSpeed;
    speedDisplay.innerText = parseFloat(savedSpeed).toFixed(2) + "x";
    setInterval(() => {
        const v = document.querySelector("video");
        if(v && v.playbackRate !== parseFloat(savedSpeed)) {
            v.playbackRate = parseFloat(savedSpeed);
        }
    }, 2000);
  }

  // 4. Notes Auto-Save
  const noteArea = document.getElementById("yt-notes-area");
  noteArea.value = localStorage.getItem("yt_super_notes") || "";
  noteArea.oninput = (e) => localStorage.setItem("yt_super_notes", e.target.value);

  // 5. OCR Functionality (Preserved)
  document.getElementById("ocr-btn").onclick = runOCR;
}