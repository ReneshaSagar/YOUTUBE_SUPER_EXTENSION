// Wait for page load completely
window.addEventListener("load", () => {
  // Initialize UI
  setTimeout(buildUI, 1500); // Small delay to let YouTube frameworks load

  // Handle YouTube SPA Navigation (URL changes without reload)
  let lastUrl = location.href; 
  new MutationObserver(() => {
    const url = location.href;
    if (url !== lastUrl) {
      lastUrl = url;
      // Re-apply speed or themes if lost during navigation
      const savedTheme = localStorage.getItem("yt_super_theme");
      if(savedTheme) applyTheme(savedTheme);
      
      const savedSpeed = localStorage.getItem("yt_super_speed");
      const video = document.querySelector("video");
      if(savedSpeed && video) video.playbackRate = parseFloat(savedSpeed);
      
      // Re-inject UI if it got wiped
      if(!document.getElementById("yt-super-panel")) buildUI();
    }
  }).observe(document, {subtree: true, childList: true});
});